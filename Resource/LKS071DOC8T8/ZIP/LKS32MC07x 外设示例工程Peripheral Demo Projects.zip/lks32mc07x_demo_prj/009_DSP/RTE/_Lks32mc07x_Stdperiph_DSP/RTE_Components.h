
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'LKS32MC07x_StdperiPh_DSP' 
 * Target:  'Lks32mc07x_Stdperiph_DSP' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "LKS32MC07x.h"



#endif /* RTE_COMPONENTS_H */
