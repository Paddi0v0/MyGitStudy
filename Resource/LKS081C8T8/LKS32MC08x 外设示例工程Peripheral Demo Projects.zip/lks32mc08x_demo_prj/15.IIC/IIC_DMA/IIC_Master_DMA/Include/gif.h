#ifndef __GIF_H_
#define __GIF_H_

#include "hardware_config.h"

extern const u8 gif_1_1[];
extern const u8 gif_1_2[];
extern const u8 gif_1_3[];
extern const u8 gif_1_4[];
extern const u8 gif_1_5[];
extern const u8 gif_1_6[];
extern const u8 gif_1_7[];
extern const u8 gif_1_8[];
extern const u8 gif_1_9[];
extern const u8 gif_2[90][680];


#endif

