#include "hardinit.h"
#include "lks32mc08x.h"


void Clock_Init(void)
{
	SYS_WR_PROTECT = 0x7a83;
	SYS_AFE_REG5 |= 0x8000;
	SYS_CLK_CFG |= 0x000001ff;		/* select fast clock */
	SYS_CLK_DIV2  = 0x0000;
	SYS_CLK_FEN = 0xff;
}

void SystemInit(void)
{
    Clock_Init();
}

void InitCom(void)
{
	GPIO0_PIE = BIT15;				// RX-P0.15
	GPIO1_POE = BIT0;				// TX-P1.0 
	
	GPIO0_FFEDC = 0x4000;
	GPIO1_F3210 = 0x0004;
	
	UART0_DIVH = 0x27;
	UART0_DIVL = 0x0F;
	UART0_IE = 0x02;

	UTIMER_UNT0_CFG = 0x0400;
	UTIMER_UNT0_TH = 0xFB80;		//48000
	UTIMER_CFG = 0x10;
	UTIMER_IE = 0x01;
}
