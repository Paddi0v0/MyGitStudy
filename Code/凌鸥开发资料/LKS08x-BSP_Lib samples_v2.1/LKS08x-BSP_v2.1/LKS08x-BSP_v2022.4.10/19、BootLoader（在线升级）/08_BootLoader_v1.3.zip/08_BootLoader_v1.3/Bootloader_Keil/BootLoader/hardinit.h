#ifndef HARDINIT_H_
#define HARDINIT_H_

void Clock_Init(void);
void SystemInit(void);

void InitCom(void);

#endif
