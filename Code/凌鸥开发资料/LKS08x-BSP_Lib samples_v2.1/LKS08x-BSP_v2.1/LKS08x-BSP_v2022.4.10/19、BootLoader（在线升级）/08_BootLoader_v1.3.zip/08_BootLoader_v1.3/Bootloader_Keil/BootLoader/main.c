
/*-----------------------------------------------------------------------------*/
/* Including Files											                   */
/*-----------------------------------------------------------------------------*/
#include "hardinit.h"
#include "comdata.h"

volatile u8 jumpFlg = 0;

int main()
{
    __disable_irq();
    SYS_WR_PROTECT = PSW_SYS_PROTECT;

	Clock_Init();
    InitRecvData();
    InitHexData();
	InitCom();
	
    NVIC_EnableIRQ(UART0_IRQn);
    NVIC_EnableIRQ(TIMER0_IRQn);
	
    __enable_irq();
   
    while(1)
	{
		CheckRecvData();
		
		if(jumpFlg)
		{
			jumpFlg = 0;
			StartUserProc();			  
		}
	}
}
