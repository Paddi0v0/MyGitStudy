.\objects\startup_lks32mc08x.o: lks32mc08x_periph_driver\Source\startup_lks32mc08x.s
