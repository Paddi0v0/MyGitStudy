/*******************************************************************************
 * ��Ȩ���� (C)2021, LINKO SEMICONDUCTOR Co.ltd
 *
 * �ļ����ƣ� lks32mc03x_HAL.h
 * �ļ���ʶ��
 * ����ժҪ�� lks32mc03x_HAL��
 * ����˵���� ��
 * ��ǰ�汾�� V 1.0
 * ��    �ߣ� YangZJ
 * ������ڣ� 2021��11��11��
 *
 *******************************************************************************/

#ifndef __lks32mc03x_LIB_H
#define __lks32mc03x_LIB_H

#include "lks32mc03x.h"
#include "basic.h"

#include "lks32mc03x_adc.h   "
#include "lks32mc03x_cmp.h   "
#include "lks32mc03x_dac.h   "
#include "lks32mc03x_dma.h   "
#include "lks32mc03x_dsp.h   "
#include "lks32MC03x_flash.h "
#include "lks32mc03x_gpio.h  "
#include "lks32mc03x_hall.h  "
#include "lks32mc03x_i2c.h   "
#include "lks32mc03x_iwdg.h  "
#include "lks32mc03x_mcpwm.h "
#include "lks32mc03x_nvr.h   "
#include "lks32mc03x_opa.h   "
#include "lks32mc03x_spi.h   "
#include "lks32mc03x_sys.h   "
#include "lks32mc03x_timer.h "
#include "lks32mc03x_uart.h  "
#include "lks32mc03x_tmp.h   "

#endif /*__lks32mc03x_HAL_H */

/************************ (C) COPYRIGHT LINKO SEMICONDUCTOR *****END OF FILE****/
